#include "syscall.h" 

void main() 
{
    int n = 1 ; 
    PrintInt(n);
    
}