#include "syscall.h" 

void main() 
{
    int n = 2  ; 
    PrintInt(n);
        
}