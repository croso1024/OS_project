#include "syscall.h" 

void main() 
{
    int n = 3  ; 
    PrintInt(n);
        
}