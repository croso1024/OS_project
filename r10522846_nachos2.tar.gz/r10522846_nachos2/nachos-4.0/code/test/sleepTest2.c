#include "syscall.h" 

main() 
{
    int i ; 

    for( i = 0 ; i < 10 ; i++ ) {
        Sleep(1000);
        PrintInt(10) ; 

    }
    return 0 ; 
}